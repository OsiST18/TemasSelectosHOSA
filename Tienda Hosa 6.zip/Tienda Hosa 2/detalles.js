document.addEventListener('DOMContentLoaded', function() {
    const params = new URLSearchParams(window.location.search);
    const productoId = params.get('id');

    const producto = productos.find(p => p.id == productoId);

    if (producto) {
        cargarDatosProducto(producto);
    }

    document.querySelector('.toggle-button').addEventListener('click', toggleForm);
    document.getElementById('carro').addEventListener('click', function() {
        agregarAlCarrito(producto);
    });
});

function cargarDatosProducto(producto) {
    document.querySelector('.main-image').src = producto.imagen;
    document.querySelectorAll('.thumbnail-images img').forEach((img, index) => {
        img.src = producto.miniaturas[index];
    });
    document.querySelector('.product-info h1').textContent = producto.nombre;
    document.querySelector('.price').textContent = `$${producto.precio} MXN`;
    document.querySelector('.description').textContent = producto.descripcion;

    const sizeOptionsContainer = document.querySelector('.size-options');
    sizeOptionsContainer.innerHTML = '';
    producto.tamanos.forEach(tamano => {
        const button = document.createElement('button');
        button.classList.add('size-button');
        button.textContent = tamano;
        sizeOptionsContainer.appendChild(button);
    });

    const decorationOptionsContainer = document.querySelector('.decoration-options');
    decorationOptionsContainer.innerHTML = '';
    producto.decoraciones.forEach(decoracion => {
        const button = document.createElement('button');
        button.classList.add('decoration-button');
        button.textContent = decoracion;
        decorationOptionsContainer.appendChild(button);
    });

    const coverOptionsContainer = document.querySelector('.cover-options');
    coverOptionsContainer.innerHTML = '';
    producto.cubiertas.forEach(cubierta => {
        const button = document.createElement('button');
        button.classList.add('cover-button');
        button.textContent = cubierta;
        coverOptionsContainer.appendChild(button);
    });
}

function toggleForm() {
    const formContainer = document.getElementById('formContainer');
    formContainer.style.display = formContainer.style.display === 'block' ? 'none' : 'block';
}

function agregarAlCarrito(producto) {
    console.log('Producto añadido al carrito:', producto);
}
