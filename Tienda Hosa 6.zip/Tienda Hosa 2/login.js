document.getElementById('loginForm').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevenir el comportamiento por defecto del formulario

  const usuarioInput = document.getElementById('usuario').value;
  const contrasenaInput = document.getElementById('contrasena').value;
  const mensaje = document.getElementById('mensaje');

  // Obtener los usuarios del localStorage
  const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

  const usuarioEncontrado = usuarios.find(usuario => usuario.usuario === usuarioInput && usuario.contrasena === contrasenaInput);

  if (usuarioEncontrado) {
    // Si las credenciales son correctas, redirigir a la página tienda.html
    window.location.href = 'principal.html';
  } else {
    // Si las credenciales son incorrectas, mostrar un mensaje de error
    mensaje.textContent = 'Usuario o contraseña incorrectos';
  }
});
