

const productos = [
    {
        id: 1,
        nombre: "Pastel de Chocolate",
        descripcion: "Un sueño hecho realidad para los amantes del chocolate. Un bizcocho húmedo y esponjoso bañado en una rica ganache de chocolate.",
        fotos: {
            principal: `imagenes/american-heritage-chocolate-Id8BO472TbY-unsplash.jpg`,
            miniatura: `imagenes/american-heritage-chocolate-Id8BO472TbY-unsplash.jpg`
        },
        precio: 500, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 2,
        nombre: "Pastel de Vainilla Clásica",
        descripcion: "Un clásico atemporal que nunca falla. Un suave bizcocho de vainilla con un toque de vainilla real, cubierto con crema batida esponjosa.",
        fotos: {
            principal: `imagenes/vainillafruta.jpg`,
            miniatura: `imagenes/vainillafruta.jpg`
        },
        precio: 500, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 3, 
        nombre: "Pastel de Zanahoria Irresistible",
        descripcion: "Un pastel húmedo y especiado con un toque de canela y nueces, cubierto con un cremoso glaseado de queso crema.",
        fotos: {
            principal: `imagenes/cristina-matos-albers-1Uqa6n1PLPU-unsplash.jpg`,
            miniatura: `imagenes/cristina-matos-albers-1Uqa6n1PLPU-unsplash.jpg`
        },
        precio: 500, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 4,
        nombre: "Cheesecake de Frutos Rojos",
        descripcion: "Una base crujiente de galletas cubierta con una crema de queso suave y cremosa, coronada con una explosión de frutos rojos frescos.",
        fotos: {
            principal: `imagenes/frutosrojos.jpg`,
            miniatura: `imagenes/frutosrojos.jpg`
        },
        precio: 500, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 5,
        nombre: "Mousse de Chocolate Delicado",
        descripcion: "Una mousse ligera y aireada hecha con chocolate de alta calidad, perfecta para un final elegante.",
        fotos: {
            principal: `imagenes/chocolate.jpg`,
            miniatura: `imagenes/chocolate.jpg`
        },
        precio: 500, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 6,
        nombre: "Pastel de Limón Refrescante",
        descripcion: "Un bizcocho húmedo de limón cubierto con un merengue esponjoso y cítrico, perfecto para un día caluroso.",
        fotos: {
            principal: `imagenes/paycho.jpg`,
            miniatura: `imagenes/paycho.jpg`
        },
        precio: 500, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 7,
        nombre: "Galletas Crujientes de Naranja",
        descripcion: "Galletas horneadas a la perfección con un toque de naranja fresca, ideales para disfrutar con una taza de café o té.",
        fotos: {
            principal: `imagenes/cookies-8668140_640.jpg`,
            miniatura: `imagenes/cookies-8668140_640.jpg`
        },
        precio: 500, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 8,
        nombre: "Brownies de Chocolate con Nueces",
        descripcion: "Un clásico irresistible: brownies húmedos y chocolateados con crujientes nueces pecanas.",
        fotos: {
            principal: `imagenes/brawni.png`,
            miniatura: `imagenes/brawni.png`
        },
        precio: 200, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 9,
        nombre: "Cupcakes de Vainilla y Chocolate",
        descripcion: "La combinación perfecta: cupcakes esponjosos de vainilla con un toque de chocolate, decorados con una crema de mantequilla suave.",
        fotos: {
            principal: `imagenes/cupcakes.jpg`,
            miniatura: `imagenes/cupcakes.jpg`
        },
        precio: 700, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 10,
        nombre: "Pastel de Manzana Casera",
        descripcion: "Un clásico reconforte postre",
        fotos: {
            principal: `imagenes/pastelBack.jpg`,
            miniatura: `imagenes/pastelBack.jpg`
        },
        precio: 400, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 11,
        nombre: "Pastel de Queso con Arándanos",
        descripcion: "Un postre delicioso y fácil de hacer",
        fotos: {
            principal: `imagenes/galleta pastel.jpg`,
            miniatura: `imagenes/galleta pastel.jpg`
        },
        precio: 300, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 12,
        nombre: "Galletas de Avena y Pasas",
        descripcion: "Unas galletas deliciosas y saludables",
        fotos: {
            principal: `imagenes/chocolate.jpg`,
            miniatura: `imagenes/chocolate.jpg`
        },
        precio: 400, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 13,
        nombre: "Cupcakes de Chocolate y Frambuesa",
        descripcion: "Un postre delicioso y fácil de hacer",
        fotos: {
            principal: `imagenes/cupcakes.jpg`,
            miniatura: `imagenes/cupcakes.jpg`
        },
        precio: 500, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 14,
        nombre: "Pastel de Chocolate y Avellanas",
        descripcion: "Un postre delicioso y fácil de hacer",
        fotos: {
            principal: `imagenes/pastelffoch.jpg`,
            miniatura: `imagenes/pastelffoch.jpg`
        },
        precio: 250, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
        id: 15,
        nombre: "Brownies de Chocolate y Caramelo",
        descripcion: "Un postre delicioso y fácil de hacer",
        fotos: {
            principal: `imagenes/brawni.png`,
            miniatura: `imagenes/brawni.png`
        },
        precio: 500, 
        tamano:[
            "Pequeño",
            "Mediano",
            "Grande",
            "Extra Grande"
        ],
        decoraciones:[
            "Chispas de chocolate", 
            "Conffeti", 
            "Galletas Oreo", 
            "Mango", 
            "Piña", 
            "Fresa"
        ],
        cubierta:[
            "Crema Batida Chocolate", 
            "Crema Batida Vainilla", 
            "Crema de Mantequilla Vainilla", 
            "Crema de Mantequilla Chocolate", 
            "Crema Batida Café"
        ]
    },
    {
            id: 16,
            nombre: "Postre de Limón",
            descripcion: "Un clásico refrescante y ácido, perfecto para un día caluroso.",
            fotos: {
                principal: "imagenes/payqueso.png",
                miniatura: "imagenes/payqueso.png"
            },
            precio: 300, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 17,
            nombre: "Tiramisú",
            descripcion: "Un postre italiano irresistible, con capas de café, bizcocho y queso mascarpone.",
            fotos: {
                principal: "imagenes/payqueso.png",
                miniatura: "imagenes/payqueso.png"
            },
            precio: 300, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 18,
            nombre: "Macarons",
            descripcion: "Pequeños dulces franceses de colores vibrantes y sabores deliciosos.",
            fotos: {
                principal: "imagenes/maccarons.jpg",
                miniatura: "imagenes/maccarons.jpg"
            },
            precio: 150, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 19,
            nombre: "Helado",
            descripcion: "Un postre cremoso y fresco que viene en una gran variedad de sabores.",
            fotos: {
                principal: "imagenes/pastelBack.jpg",
                miniatura: "imagenes/pastelBack.jpg"
            },
            precio: 100, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 20,
            nombre: "Galletas",
            descripcion: "Un clásico hogareño que se puede disfrutar solo o con una taza de café o leche.",
            fotos: {
                principal: "imagenes/galletaschis.jpg",
                miniatura: "imagenes/galletaschis.jpg"
            },
            precio: 100, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 21,
            nombre: "Pastel de Boda",
            descripcion: "Un postre suave y cremoso con un toque de caramelo.",
            fotos: {
                principal: "imagenes/pastelboda.jpg",
                miniatura: "imagenes/pastelboda.jpg"
            },
            precio: 150, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 22,
            nombre: "Brownie",
            descripcion: "Un postre chocolatoso y húmedo que nunca falla.",
            fotos: {
                principal: "imagenes/brawni.png",
                miniatura: "imagenes/brawni.png"
            },
            precio: 250, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 23,
            nombre: "Cheesecake",
            descripcion: "Un postre cremoso y versátil que se puede preparar con diferentes sabores.",
            fotos: {
                principal: "imagenes/cheeskae.jpg",
                miniatura: "imagenes/cheeskae.jpg"
            },
            precio: 600, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 24,
            nombre: "Crepes",
            descripcion: "Delgados panqueques franceses que se pueden rellenar con dulces o salados.",
            fotos: {
                principal: "imagenes/crepas.jpg",
                miniatura: "imagenes/crepas.jpg"
            },
            precio: 100, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 25,
            nombre: "Muffins",
            descripcion: "Pequeños pasteles húmedos y esponjosos, perfectos para un desayuno o una merienda.",
            fotos: {
                principal: "imagenes/cupcakes.jpg",
                miniatura: "imagenes/cupcakes.jpg"
            },
            precio: 500, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 26,
            nombre: "Pastel de Manzana",
            descripcion: "Un clásico hogareño con una corteza crujiente y un relleno de manzana dulce.",
            fotos: {
                principal: "imagenes/Imagen 1.jpg",
                miniatura: "imagenes/Imagen 1.jpg"
            },
            precio: 400, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 27,
            nombre: "Croissants",
            descripcion: "Pasteles franceses hojaldrados y mantecosos, perfectos para un desayuno o una merienda.",
            fotos: {
                principal: "imagenes/croissant.jpg",
                miniatura: "imagenes/croissant.jpg"
            },
            precio: 300, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 28,
            nombre: "Pastel de Fresa",
            descripcion: "Un postre fresco y frutal, perfecto para los amantes de las fresas.",
            fotos: {
                principal: "imagenes/frutosrojos.jpg",
                miniatura: "imagenes/frutosrojos.jpg"
            },
            precio: 500, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 29,
            nombre: "Gelatina",
            descripcion: "Un postre ligero y refrescante que viene en una variedad de sabores y colores.",
            fotos: {
                principal: "imagenes/paycho.jpg",
                miniatura: "imagenes/paycho.jpg"
            },
            precio: 100, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        },
        {
            id: 30,
            nombre: "Pastel de Chocolate",
            descripcion: "Un postre rico y decadente para los amantes del chocolate.",
            fotos: {
                principal: "imagenes/payquesocho.png",
                miniatura: "imagenes/payquesocho.png"
            },
            precio: 400, 
            tamano:[
                "Pequeño",
                "Mediano",
                "Grande",
                "Extra Grande"
            ],
            decoraciones:[
                "Chispas de chocolate", 
                "Conffeti", 
                "Galletas Oreo", 
                "Mango", 
                "Piña", 
                "Fresa"
            ],
            cubierta:[
                "Crema Batida Chocolate", 
                "Crema Batida Vainilla", 
                "Crema de Mantequilla Vainilla", 
                "Crema de Mantequilla Chocolate", 
                "Crema Batida Café"
            ]
        }
    
];
