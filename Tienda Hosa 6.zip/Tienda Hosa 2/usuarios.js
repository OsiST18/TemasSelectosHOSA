const usuarios = [
    {
      id: 1,
      usuario : "a2203040329@alumnos.uat.edu.mx",
      contrasena: "12345678"
    }, 

     {
       id: 2,
       usuario : "a2203040355@alumnos.uat.edu.mx",
       contrasena: "12345678"
     },

     {
        id: 3,
        usuario : "prueba@alumnos.uat.edu.mx",
        contrasena: "123Contraseña"
      },
      {
        id: 4,
        usuario : "a2203040349@alumnos.uat.edu.mx",
        contrasena:"12345678"
      }
]; 
  
// Guardar los usuarios en localStorage
localStorage.setItem('usuarios', JSON.stringify(usuarios));
  