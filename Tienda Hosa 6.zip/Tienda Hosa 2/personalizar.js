document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const productoId = parseInt(urlParams.get('productoId'), 10);
    const producto = productos.find(p => p.id === productoId);
    let carro = JSON.parse(localStorage.getItem('carro')) || [];

    if (producto) {
        renderizarPersonalizacion(producto);
    }
});

function renderizarPersonalizacion(producto) {
    const contenedor = document.getElementById('personalizacion-container');
    contenedor.innerHTML = `
        <h2>Personalizar ${producto.nombre}</h2>
        <img class="main-image" src="${producto.fotos.principal}" alt="${producto.nombre}">
        <p>${producto.descripcion}</p>
        
        <h3>Tamaño</h3>
        ${producto.tamano.map((tam, index) => `
            <label class="btn btn-outline-primary" for="btnradio1">
                <input type="radio" name="tamano" value="${tam}" ${index === 0 ? 'checked' : ''}>
                ${tam}
            </label>
        `).join('')}
        
        <h3>Decoraciones</h3>
        ${producto.decoraciones.map((decoracion, index) => `
            <label class="btn btn-outline-primary" for="btnradio2">
                <input type="radio" name="decoracion" value="${decoracion}" ${index === 0 ? 'checked' : ''}>
                ${decoracion}
            </label>
        `).join('')}
        
        <h3>Cubierta</h3>
        ${producto.cubierta.map((cubierta, index) => `
            <label class="btn btn-outline-primary" for="btnradio3">
                <input type="radio" name="cubierta" value="${cubierta}" ${index === 0 ? 'checked' : ''}>
                ${cubierta}
            </label>
        `).join('')}
        
        <button class="btnPersonalizarProducto" onclick="agregarPersonalizadoAlCarro(${producto.id})">Agregar al Carro</button>
    `;
}

function agregarPersonalizadoAlCarro(productoId) {
    const producto = productos.find(p => p.id === productoId);
    const tamano = document.querySelector('input[name="tamano"]:checked').value;
    const decoracion = document.querySelector('input[name="decoracion"]:checked').value;
    const cubierta = document.querySelector('input[name="cubierta"]:checked').value;

    const productoPersonalizado = {
        ...producto,
        tamanoSeleccionado: tamano,
        decoracionSeleccionada: decoracion,
        cubiertaSeleccionada: cubierta,
    };

    let carro = JSON.parse(localStorage.getItem('carro')) || [];

    const productoEnCarro = carro.find(p => p.id === productoId && p.tamanoSeleccionado === tamano && p.decoracionSeleccionada === decoracion && p.cubiertaSeleccionada === cubierta);
    if (productoEnCarro) {
        productoEnCarro.cantidad++;
    } else {
        carro.push({ ...productoPersonalizado, cantidad: 1 });
    }

    localStorage.setItem('carro', JSON.stringify(carro));

    alert('Producto agregado al carrito');
    // Renderizar el carrito en la página principal de la tienda
    window.location.href = 'tienda.html';
}

