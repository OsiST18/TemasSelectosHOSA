document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('loginButton').addEventListener('click', function() {
        window.location.href = 'login.html'; // Reemplaza 'login.html' con la URL de tu página de inicio de sesión
    });
});

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('buscar').addEventListener('click', function() {
        const query = document.getElementById('buscarInput').value.toLowerCase();
        const resultsContainer = document.getElementById('results');
        // Aquí puedes añadir tu lógica de búsqueda
        // Por ejemplo, si tienes una lista de elementos a buscar:
        const items = ['Manzana', 'Banana', 'Cereza', 'Dátil']; // Ejemplo de datos

        // Filtrar resultados
        const filteredItems = items.filter(item => item.toLowerCase().includes(query));

        // Mostrar resultados
        resultsContainer.innerHTML = filteredItems.length > 0
            ? filteredItems.join('<br>')
            : 'No se encontraron resultados.';
    });
});

function toggleForm() {
    var formContainer = document.getElementById('formContainer');
    if (formContainer.style.display === 'none' || formContainer.style.display === '') {
        formContainer.style.display = 'block';
    } else {
        formContainer.style.display = 'none';
    }
}